import 'package:flutter/material.dart';
import 'package:healthforecast/Features/Admin/TapAdmin/presentation/view/tabs_screen.dart';

import '../../../../Core/UI/primary_button.dart';
import '../../../../Core/Utils/App Colors.dart';
import '../../../../Core/Utils/App Textstyle.dart';
import '../../../../Core/Utils/Assets Manager.dart';
import '../../../../Core/Utils/Core Components.dart';
import '../../../../Core/Utils/Shared Methods.dart';
import '../../../Patient/Home/presentation/view/tabs_screen.dart';
import '../manger/AdminAcount.dart';
import 'Signup_Screen.dart';

class LoginScreen extends StatelessWidget {
  LoginScreen({super.key});

  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  final formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    AppBar appBar = AppBar(
      backgroundColor: Colors.white,
      elevation: 0,
      leading: Container(),
    );
    final mediaQueryHeight = MediaQuery.of(context).size.height;
    final mediaQueryWidth = MediaQuery.of(context).size.width;
    final mediaQueryTop = MediaQuery.of(context).padding.top;
    final mediaQuery =
        (mediaQueryHeight - appBar.preferredSize.height - mediaQueryTop);
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: appBar,
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 13),
        child: CustomScrollView(
          physics: const ScrollPhysics(),
          keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
          shrinkWrap: true,
          slivers: [
            SliverFillRemaining(
              hasScrollBody: false,
              child: Form(
                key: formKey,
                child: SizedBox(
                  height: mediaQuery,
                  child: Column(
                    children: [
                      Expanded(
                        flex: 3,
                        child: Hero(
                          tag: "sign",
                          child: Image.asset(
                            AssetsManager.onBoarding1,
                            fit: BoxFit.fill,
                          ),
                        ),
                      ),
                      SizedBox(height: mediaQuery * 0.01),
                      Padding(
                        padding: EdgeInsets.all(mediaQuery * 0.014),
                        child: Container(
                          alignment: Alignment.topLeft,
                          height: mediaQuery * 0.060,
                          child: FittedBox(
                            child: Hero(
                              tag: "login",
                              child: Text(
                                "Login",
                                style: AppTextStyles.titleText,
                              ),
                            ),
                          ),
                        ),
                      ),
                      Expanded(
                          flex: 5,
                          child: LayoutBuilder(
                            builder: (BuildContext context,
                                BoxConstraints constraints) {
                              return Column(children: [
                                Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: TextFieldTemplate(
                                    name: 'username',
                                    label: 'Enter The Email',
                                    controller: emailController,
                                    leadingIcon: Icons.mail_outline,
                                    boolleadingIcon: true,
                                    leadingIconColor: AppColors.greenYellow,
                                    enableFocusBorder: false,
                                    titel: "Email",
                                    validator: (value) => value!.isEmpty
                                        ? "email is required"
                                        : null,
                                  ),
                                ),
                                SizedBox(
                                  height: constraints.maxHeight * 0.02,
                                ),
                                Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: TextFieldTemplate(
                                    titel: "Password",
                                    name: 'password',
                                    controller: passwordController,
                                    label: 'Enter The Password',
                                    inputType: TextInputType.visiblePassword,
                                    leadingIconColor: AppColors.greenYellow,
                                    enableFocusBorder: false,
                                    validator: (value) {
                                      if (value!.isEmpty) {
                                        return 'Please enter your password';
                                      }
                                      return null;
                                    },
                                  ),
                                ),
                                SizedBox(
                                  height: constraints.maxHeight * 0.07,
                                ),
                                Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Hero(
                                    tag: "button",
                                    child: PrimaryButton(
                                      label: "Login",
                                      // isLoading:state is LoginLoadingState,
                                      foregroundColor: AppColors.white,
                                      backgroundColor: AppColors.blue,
                                      onPressed: () {
                                        if (formKey.currentState!.validate()) {
                                          if (emailController.text ==
                                                  Admin["email"] &&
                                              passwordController.text ==
                                                  Admin["password"]) {
                                            //صفحات الادمن
                                            navigateAndFinished(
                                                context, const TabsAdminScreen());
                                          } else {
                                            //صفحات المريض
                                            navigateAndFinished(context, TabsScreen());

                                          }
                                        }
                                      },
                                    ),
                                  ),
                                ),
                                SizedBox(
                                  height: constraints.maxHeight * .047,
                                ),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    SizedBox(
                                      height: constraints.maxHeight * .1,
                                      width: constraints.maxWidth * 0.45,
                                      child: FittedBox(
                                        child: Text(
                                          "Already have an account ? ",
                                          style: AppTextStyles.titleText2,
                                        ),
                                      ),
                                    ),
                                    InkWell(
                                      onTap: () {
                                        navigateTo(context, SignUp());
                                        // navigateTo(
                                        //     context, BlocProvider.value(
                                        //     value: cubit,
                                        //     child: SignUp()));
                                      },
                                      child: SizedBox(
                                        height: constraints.maxHeight * .11,
                                        width: constraints.maxWidth * 0.27,
                                        child: FittedBox(
                                          child: Text(
                                            "Registration",
                                            style: AppTextStyles.titleText,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ]);
                            },
                          )),
                    ],
                  ),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
